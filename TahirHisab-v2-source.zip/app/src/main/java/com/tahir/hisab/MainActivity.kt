package com.tahir.hisab

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF14213D)
private val Gold = Color(0xFFE0B45C)
private val Pale = Color(0xFFF3F5F9)
private val Green = Color(0xFF16845B)
private val Red = Color(0xFFC74747)
private const val AFN = "AFN"
private const val IRR = "IRR"

private fun moneyUnit(currency: String) = if (currency == IRR) "تومان" else "افغانی"
private fun hashPin(pin: String): String = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString("") { "%02x".format(it) }

data class Entry(val id: Long, val title: String, val amount: Long, val income: Boolean, val date: String, val currency: String = AFN)
data class Debt(val id: Long, val person: String, val amount: Long, val isReceivable: Boolean, val currency: String, val note: String, val paid: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { TahirHisabApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TahirHisabApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tahir_hisab", Context.MODE_PRIVATE) }
    val entries = remember { mutableStateListOf<Entry>().apply { addAll(loadEntries(prefs)) } }
    val debts = remember { mutableStateListOf<Debt>().apply { addAll(loadDebts(prefs)) } }
    var unlocked by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }
    var changingPin by remember { mutableStateOf(false) }
    var showPinSetup by remember { mutableStateOf(false) }
    var profileName by remember { mutableStateOf(prefs.getString("profile_name", "طاهر") ?: "طاهر") }
    var photoUri by remember { mutableStateOf(prefs.getString("profile_photo", null)) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var editEntry by remember { mutableStateOf<Entry?>(null) }
    var showDebt by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var incomeMode by remember { mutableStateOf(true) }
    var currency by remember { mutableStateOf(AFN) }
    var debtPerson by remember { mutableStateOf("") }
    var debtAmount by remember { mutableStateOf("") }
    var debtNote by remember { mutableStateOf("") }
    var debtReceivable by remember { mutableStateOf(true) }
    var debtCurrency by remember { mutableStateOf(AFN) }
    var editingProfile by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            photoUri = uri.toString(); prefs.edit().putString("profile_photo", photoUri).apply()
        }
    }
    fun saveEntries() { prefs.edit().putString("entries", entriesToJson(entries)).apply() }
    fun saveDebts() { prefs.edit().putString("debts", debtsToJson(debts)).apply() }
    val afnIncome = entries.filter { it.currency == AFN && it.income }.sumOf { it.amount }
    val afnExpense = entries.filter { it.currency == AFN && !it.income }.sumOf { it.amount }
    val irrIncome = entries.filter { it.currency == IRR && it.income }.sumOf { it.amount }
    val irrExpense = entries.filter { it.currency == IRR && !it.income }.sumOf { it.amount }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Gold, background = Pale, surface = Color.White)) {
        if (!unlocked) {
            val savedPin = prefs.getString("pin_hash", null)
            if (savedPin == null) showPinSetup = true
            Surface(Modifier.fillMaxSize(), color = Navy) {
                Column(Modifier.fillMaxSize().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.Lock, null, tint = Gold, modifier = Modifier.size(58.dp))
                    Spacer(Modifier.height(18.dp))
                    Text("طاهر حساب", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(if (savedPin == null) "برای برنامه رمز چهاررقمی بسازید" else "رمز چهاررقمی را وارد کنید", color = Color(0xFFD9E0EF))
                    Spacer(Modifier.height(24.dp))
                    OutlinedTextField(value = pinInput, onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pinInput = it }, label = { Text("رمز چهاررقمی", color = Color.White) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Gold, unfocusedBorderColor = Color.LightGray, cursorColor = Gold))
                    if (savedPin == null) {
                        OutlinedTextField(value = pinConfirm, onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pinConfirm = it }, label = { Text("تکرار رمز", color = Color.White) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Gold, unfocusedBorderColor = Color.LightGray))
                    }
                    if (pinError.isNotBlank()) Text(pinError, color = Color(0xFFFF8A80))
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        if (pinInput.length != 4) pinError = "رمز باید دقیقاً چهار رقم باشد"
                        else if (savedPin == null) {
                            if (pinInput != pinConfirm) pinError = "رمزها یکسان نیستند"
                            else { prefs.edit().putString("pin_hash", hashPin(pinInput)).apply(); unlocked = true; pinError = "" }
                        } else if (hashPin(pinInput) == savedPin) { unlocked = true; pinError = "" } else pinError = "رمز نادرست است"
                    }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy), modifier = Modifier.fillMaxWidth()) { Text(if (savedPin == null) "ساخت رمز و ورود" else "ورود به برنامه") }
                }
            }
        } else {
            Scaffold(containerColor = Pale, topBar = {
                TopAppBar(title = { Column { Text("طاهر حساب", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp); Text("مدیریت دخل، خرج و حساب‌ها", color = Color(0xFFD9E0EF), fontSize = 12.sp) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy), actions = { IconButton(onClick = { unlocked = false; pinInput = "" }) { Icon(Icons.Default.Lock, "قفل برنامه", tint = Color.White) } })
            }, bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("خانه") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.People, null) }, label = { Text("بدهی‌ها") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("پروفایل") })
                }
            }, floatingActionButton = {
                if (tab == 0) FloatingActionButton(onClick = { editEntry = null; title = ""; amount = ""; incomeMode = true; currency = AFN; showAdd = true }, containerColor = Gold, contentColor = Navy) { Icon(Icons.Default.Add, "افزودن حساب") }
                if (tab == 1) FloatingActionButton(onClick = { debtPerson = ""; debtAmount = ""; debtNote = ""; debtReceivable = true; debtCurrency = AFN; showDebt = true }, containerColor = Gold, contentColor = Navy) { Icon(Icons.Default.Add, "افزودن بدهی") }
            }) { padding ->
                when (tab) {
                    0 -> Column(Modifier.fillMaxSize().padding(padding).padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { ProfileAvatar(photoUri, 42); Spacer(Modifier.width(10.dp)); Column { Text("سلام، $profileName", fontWeight = FontWeight.Bold, color = Navy); Text("خوش آمدید", color = Color.Gray, fontSize = 12.sp) } }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CurrencySummary("افغانی", afnIncome, afnExpense, Modifier.weight(1f))
                            CurrencySummary("تومان", irrIncome, irrExpense, Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("تراکنش‌ها", fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
                        if (entries.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("هنوز حسابی ثبت نشده است.\nبرای شروع دکمه + را بزنید.", color = Color.Gray) }
                        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(entries.sortedByDescending { it.id }, key = { it.id }) { item ->
                                Card(shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) { Text(item.title, color = Navy, fontWeight = FontWeight.SemiBold); Text(item.date, color = Color.Gray, fontSize = 11.sp) }
                                        Column(horizontalAlignment = Alignment.End) { Text("${if (item.income) "+" else "−"}${item.amount}", color = if (item.income) Green else Red, fontWeight = FontWeight.Bold); Text(moneyUnit(item.currency), color = Color.Gray, fontSize = 11.sp) }
                                        IconButton(onClick = { editEntry = item; title = item.title; amount = item.amount.toString(); incomeMode = item.income; currency = item.currency; showAdd = true }) { Icon(Icons.Default.Edit, "ویرایش", tint = Navy) }
                                        IconButton(onClick = { entries.remove(item); saveEntries() }) { Icon(Icons.Default.Delete, "حذف", tint = Red) }
                                    }
                                }
                            }
                        }
                    }
                    1 -> Column(Modifier.fillMaxSize().padding(padding).padding(14.dp)) {
                        Text("مدیریت بدهکاران و طلبکاران", color = Navy, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Spacer(Modifier.height(10.dp))
                        if (debts.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("هنوز موردی ثبت نشده است. دکمه + را بزنید.", color = Color.Gray) }
                        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(debts.toList(), key = { it.id }) { d ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(d.person, color = Navy, fontWeight = FontWeight.Bold); Text(if (d.isReceivable) "طلب من" else "بدهی من", color = if (d.isReceivable) Green else Red, fontSize = 12.sp); if (d.note.isNotBlank()) Text(d.note, color = Color.Gray, fontSize = 11.sp) }
                                    Column(horizontalAlignment = Alignment.End) { Text("${d.amount} ${moneyUnit(d.currency)}", color = Navy, fontWeight = FontWeight.Bold); Text(if (d.paid) "تسویه شده" else "پرداخت نشده", color = if (d.paid) Green else Red, fontSize = 11.sp) }
                                    Checkbox(checked = d.paid, onCheckedChange = { checked -> val i = debts.indexOfFirst { it.id == d.id }; if (i >= 0) debts[i] = d.copy(paid = checked); saveDebts() })
                                    IconButton(onClick = { debts.remove(d); saveDebts() }) { Icon(Icons.Default.Delete, null, tint = Red) }
                                }
                            }
                        } }
                    }
                    else -> Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        ProfileAvatar(photoUri, 104)
                        Spacer(Modifier.height(10.dp))
                        Text(profileName, color = Navy, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                        Text("پروفایل صاحب حساب", color = Color.Gray)
                        Spacer(Modifier.height(18.dp))
                        Button(onClick = { photoPicker.launch(arrayOf("image/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Navy), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PhotoCamera, null); Spacer(Modifier.width(8.dp)); Text("انتخاب عکس پروفایل") }
                        OutlinedButton(onClick = { editingProfile = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(8.dp)); Text("تغییر نام") }
                        OutlinedButton(onClick = { changingPin = true; pinInput = ""; pinConfirm = ""; pinError = "" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Lock, null); Spacer(Modifier.width(8.dp)); Text("تغییر رمز چهاررقمی") }
                        Spacer(Modifier.height(18.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text("گزارش خلاصه", fontWeight = FontWeight.Bold, color = Navy); Text("درآمد افغانی: $afnIncome   |   مصرف افغانی: $afnExpense", fontSize = 12.sp); Text("درآمد تومان: $irrIncome   |   مصرف تومان: $irrExpense", fontSize = 12.sp); Text("تعداد تراکنش‌ها: ${entries.size}", fontSize = 12.sp) } }
                    }
                }
            }
        }

        if (showAdd) AlertDialog(onDismissRequest = { showAdd = false }, title = { Text(if (editEntry == null) "ثبت حساب جدید" else "ویرایش حساب") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(selected = incomeMode, onClick = { incomeMode = true }, label = { Text("درآمد") }); FilterChip(selected = !incomeMode, onClick = { incomeMode = false }, label = { Text("مصرف") }) }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("عنوان حساب") }, singleLine = true)
                OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text("مبلغ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Text("واحد پول", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(selected = currency == AFN, onClick = { currency = AFN }, label = { Text("افغانی ؋") }); FilterChip(selected = currency == IRR, onClick = { currency = IRR }, label = { Text("تومان") }) }
            }
        }, confirmButton = { TextButton(onClick = { val v = amount.toLongOrNull(); if (title.isNotBlank() && v != null && v > 0) { val date = SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.getDefault()).format(Date()); val old = editEntry; if (old != null) { val i = entries.indexOfFirst { it.id == old.id }; if (i >= 0) entries[i] = old.copy(title = title.trim(), amount = v, income = incomeMode, currency = currency) } else entries.add(Entry(System.currentTimeMillis(), title.trim(), v, incomeMode, date, currency)); saveEntries(); showAdd = false } }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = { showAdd = false }) { Text("لغو") } })

        if (showDebt) AlertDialog(onDismissRequest = { showDebt = false }, title = { Text("ثبت بدهی یا طلب") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row { FilterChip(selected = debtReceivable, onClick = { debtReceivable = true }, label = { Text("طلب من") }); Spacer(Modifier.width(6.dp)); FilterChip(selected = !debtReceivable, onClick = { debtReceivable = false }, label = { Text("بدهی من") }) }
                OutlinedTextField(value = debtPerson, onValueChange = { debtPerson = it }, label = { Text("نام شخص") }, singleLine = true)
                OutlinedTextField(value = debtAmount, onValueChange = { debtAmount = it.filter(Char::isDigit) }, label = { Text("مبلغ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(value = debtNote, onValueChange = { debtNote = it }, label = { Text("یادداشت (اختیاری)") }, singleLine = true)
                Row { FilterChip(selected = debtCurrency == AFN, onClick = { debtCurrency = AFN }, label = { Text("افغانی") }); Spacer(Modifier.width(6.dp)); FilterChip(selected = debtCurrency == IRR, onClick = { debtCurrency = IRR }, label = { Text("تومان") }) }
            }
        }, confirmButton = { TextButton(onClick = { val v = debtAmount.toLongOrNull(); if (debtPerson.isNotBlank() && v != null && v > 0) { debts.add(Debt(System.currentTimeMillis(), debtPerson.trim(), v, debtReceivable, debtCurrency, debtNote.trim(), false)); saveDebts(); showDebt = false } }) { Text("ثبت") } }, dismissButton = { TextButton(onClick = { showDebt = false }) { Text("لغو") } })

        if (editingProfile) {
            var newName by remember { mutableStateOf(profileName) }
            AlertDialog(onDismissRequest = { editingProfile = false }, title = { Text("تغییر نام پروفایل") }, text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("نام") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (newName.isNotBlank()) { profileName = newName.trim(); prefs.edit().putString("profile_name", profileName).apply(); editingProfile = false } }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = { editingProfile = false }) { Text("لغو") } })
        }
        if (changingPin) AlertDialog(onDismissRequest = { changingPin = false }, title = { Text("تغییر رمز چهاررقمی") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(value = pinInput, onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pinInput = it }, label = { Text("رمز جدید") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true); OutlinedTextField(value = pinConfirm, onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pinConfirm = it }, label = { Text("تکرار رمز جدید") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true); if (pinError.isNotBlank()) Text(pinError, color = Red) } }, confirmButton = { TextButton(onClick = { if (pinInput.length != 4) pinError = "رمز باید چهار رقم باشد" else if (pinInput != pinConfirm) pinError = "رمزها یکسان نیستند" else { prefs.edit().putString("pin_hash", hashPin(pinInput)).apply(); changingPin = false } }) { Text("ذخیره رمز") } }, dismissButton = { TextButton(onClick = { changingPin = false }) { Text("لغو") } })
    }
}

@Composable
private fun ProfileAvatar(uri: String?, size: Int) {
    if (uri != null) AsyncImage(model = uri, contentDescription = "عکس پروفایل", modifier = Modifier.size(size.dp).clip(CircleShape).background(Color(0xFFE3E8F0)))
    else Box(Modifier.size(size.dp).clip(CircleShape).background(Navy), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Gold, modifier = Modifier.size((size * .58).dp)) }
}

@Composable
private fun CurrencySummary(label: String, income: Long, expense: Long, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Navy)) {
        Column(Modifier.fillMaxWidth().padding(13.dp)) {
            Text("موجودی $label", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("${income - expense}", color = Gold, fontWeight = FontWeight.Bold, fontSize = 23.sp)
            Spacer(Modifier.height(5.dp)); Text("درآمد: $income", color = Color(0xFF8FE0B8), fontSize = 11.sp); Text("مصرف: $expense", color = Color(0xFFFFA2A2), fontSize = 11.sp)
        }
    }
}

private fun loadEntries(prefs: android.content.SharedPreferences): List<Entry> = try {
    val arr = JSONArray(prefs.getString("entries", "[]")); (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); Entry(o.getLong("id"), o.getString("title"), o.getLong("amount"), o.getBoolean("income"), o.getString("date"), o.optString("currency", AFN).ifBlank { AFN }) }
} catch (_: Exception) { emptyList() }
private fun entriesToJson(entries: List<Entry>): String { val arr = JSONArray(); entries.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("amount", it.amount).put("income", it.income).put("date", it.date).put("currency", it.currency)) }; return arr.toString() }
private fun loadDebts(prefs: android.content.SharedPreferences): List<Debt> = try { val arr = JSONArray(prefs.getString("debts", "[]")); (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); Debt(o.getLong("id"), o.getString("person"), o.getLong("amount"), o.getBoolean("isReceivable"), o.optString("currency", AFN), o.optString("note", ""), o.optBoolean("paid", false)) } } catch (_: Exception) { emptyList() }
private fun debtsToJson(debts: List<Debt>): String { val arr = JSONArray(); debts.forEach { arr.put(JSONObject().put("id", it.id).put("person", it.person).put("amount", it.amount).put("isReceivable", it.isReceivable).put("currency", it.currency).put("note", it.note).put("paid", it.paid)) }; return arr.toString() }
